/**
 * This Program was written by:
 * 
 * Garrett O'Hara cssc1136 RedId: 822936303
 * 
 * CS 480 | Professor Shen | Februrary 2022
 **/
#ifndef ARGUMENTS_H_                             // INCLUDE GUARD
#define ARGUMENTS_H_

namespace arguments{
    void process_flag(char[], char[]);           // PROCESS ARGUEMNT FLAGS
    void process_args(int , char*[]);            // PROCESS CLI ARGUMENTS
}

#endif                                           // ARGUMENTS_H_