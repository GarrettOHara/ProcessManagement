/**
 * This Program was written by:
 * 
 * Garrett O'Hara cssc1136 RedId: 822936303
 * 
 * CS 480 | Professor Shen | Februrary 2022
 **/
#ifndef SEARCHING_H_                             // INCLUDE GUARD
#define SEARCHING_H_

namespace searching{
    void* search(void*);
}

#endif                                           // SEARCHING_H_